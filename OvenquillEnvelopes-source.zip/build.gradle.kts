plugins {
    java
    id("com.gradleup.shadow") version "9.2.2"
}

group = "ru.ovenquill"
version = "1.0.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:26.2.build.135-stable")
    implementation("org.xerial:sqlite-jdbc:3.51.0.0")
    testImplementation(platform("org.junit:junit-bom:6.0.1"))
    testImplementation("org.junit.jupiter:junit-jupiter")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

tasks {
    compileJava {
        options.encoding = "UTF-8"
        options.release.set(25)
    }
    processResources {
        filteringCharset = "UTF-8"
        filesMatching("plugin.yml") { expand("version" to project.version) }
    }
    test { useJUnitPlatform() }
    shadowJar {
        archiveFileName.set("OvenquillEnvelopes.jar")
        relocate("org.sqlite", "ru.ovenquill.envelopes.lib.sqlite")
        mergeServiceFiles()
    }
    build { dependsOn(shadowJar) }
    register<Zip>("resourcePackZip") {
        archiveFileName.set("OvenquillEnvelopes-resourcepack.zip")
        destinationDirectory.set(layout.buildDirectory.dir("distributions"))
        from("resourcepack")
        val localTexture = file("resourcepack/assets/ovenquill/textures/item/envelope.png")
        val textureSource = if (localTexture.exists()) localTexture else file("C:/Users/syche/Downloads/pixil-frame-0.png")
        from(textureSource) {
            into("assets/ovenquill/textures/item")
            rename { "envelope.png" }
        }
        exclude("**/README.txt")
    }
    register<Zip>("sourceZip") {
        archiveFileName.set("OvenquillEnvelopes-source.zip")
        destinationDirectory.set(layout.buildDirectory.dir("distributions"))
        from(projectDir) {
            exclude(".gradle/**", "build/**")
        }
        from("C:/Users/syche/Downloads/pixil-frame-0.png") {
            into("resourcepack/assets/ovenquill/textures/item")
            rename { "envelope.png" }
        }
    }
    register<Copy>("deliverables") {
        dependsOn(build, named("resourcePackZip"), named("sourceZip"))
        from(layout.buildDirectory.file("libs/OvenquillEnvelopes.jar"))
        from(layout.buildDirectory.file("distributions/OvenquillEnvelopes-resourcepack.zip"))
        from(layout.buildDirectory.file("distributions/OvenquillEnvelopes-source.zip"))
        from("README.md")
        into("../outputs")
    }
    register<Copy>("repositoryRelease") {
        dependsOn(build, named("resourcePackZip"))
        from(layout.buildDirectory.file("libs/OvenquillEnvelopes.jar"))
        from(layout.buildDirectory.file("distributions/OvenquillEnvelopes-resourcepack.zip"))
        into("release")
    }
}

envelope.png is copied from the owner-provided 16x16 RGBA source.

package ru.ovenquill.envelopes;

import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import ru.ovenquill.envelopes.command.EnvelopeCommand;
import ru.ovenquill.envelopes.listener.EnvelopeListener;
import ru.ovenquill.envelopes.model.EnvelopeType;
import ru.ovenquill.envelopes.security.EnvelopeSigner;
import ru.ovenquill.envelopes.service.EnvelopeService;
import ru.ovenquill.envelopes.storage.EnvelopeStorage;

import java.nio.file.Files;
import java.security.SecureRandom;
import java.util.Base64;

public final class OvenquillEnvelopes extends JavaPlugin {
    private EnvelopeStorage storage; private EnvelopeService service;
    @Override public void onEnable(){try{saveDefaultConfig();saveResource("messages_ru.yml",false);loadMessages();byte[] secret=loadOrCreateSecret();storage=new EnvelopeStorage(getDataFolder().toPath().resolve(getConfig().getString("database.file","envelopes.db")));service=new EnvelopeService(this,storage,new EnvelopeSigner(secret));EnvelopeCommand command=new EnvelopeCommand(this);getCommand("envelope").setExecutor(command);getCommand("envelope").setTabCompleter(command);getServer().getPluginManager().registerEvents(new EnvelopeListener(service),this);reloadTypes(null);getLogger().info("OVENQUILL ENVELOPES 1.0.0 enabled (single SQLite worker, no idle tick tasks)");}catch(Exception e){getLogger().log(java.util.logging.Level.SEVERE,"Cannot enable plugin",e);getServer().getPluginManager().disablePlugin(this);}}
    private void loadMessages(){var file=YamlConfiguration.loadConfiguration(new java.io.File(getDataFolder(),"messages_ru.yml"));for(String key:file.getKeys(false))getConfig().set("_messages."+key,file.getString(key));}
    private byte[] loadOrCreateSecret() throws Exception{var path=getDataFolder().toPath().resolve("secret.key");if(Files.exists(path))return Base64.getDecoder().decode(Files.readString(path).trim());byte[] key=new byte[32];new SecureRandom().nextBytes(key);Files.createDirectories(path.getParent());Files.writeString(path,Base64.getEncoder().encodeToString(key));return key;}
    public void reloadTypes(CommandSender sender){storage.loadTypes().whenComplete((types,error)->getServer().getScheduler().runTask(this,()->{if(error!=null){getLogger().log(java.util.logging.Level.SEVERE,"Cannot load envelope types",error);if(sender!=null)sender.sendMessage("Ошибка загрузки типов.");}else{service.setTypes(types);if(sender!=null)sender.sendMessage("Загружено типов: "+types.size());}}));}
    public void saveAndReload(EnvelopeType type,CommandSender sender){storage.saveType(type).whenComplete((v,e)->{if(e==null)reloadTypes(sender);else getServer().getScheduler().runTask(this,()->sender.sendMessage("Ошибка сохранения: "+e.getMessage()));});}
    public void archiveAndReload(String id,CommandSender sender){storage.archiveType(id).thenRun(()->reloadTypes(sender));}
    public void reloadAll(CommandSender sender){reloadConfig();loadMessages();reloadTypes(sender);}
    public void status(CommandSender sender){storage.pendingCount().thenAccept(count->getServer().getScheduler().runTask(this,()->sender.sendMessage("OVENQUILL: типов="+service.types().size()+", ожидающих наград="+count+", DB worker=1")));}
    public EnvelopeStorage storage(){return storage;} public EnvelopeService service(){return service;}
    @Override public void onDisable(){if(storage!=null)storage.close();}
}

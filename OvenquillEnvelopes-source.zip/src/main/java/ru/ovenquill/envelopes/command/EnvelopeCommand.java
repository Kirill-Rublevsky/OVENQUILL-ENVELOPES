package ru.ovenquill.envelopes.command;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import ru.ovenquill.envelopes.OvenquillEnvelopes;
import ru.ovenquill.envelopes.model.EnvelopeType;
import ru.ovenquill.envelopes.model.RewardMode;

import java.util.*;

public final class EnvelopeCommand implements CommandExecutor, TabCompleter {
    private final OvenquillEnvelopes plugin;
    public EnvelopeCommand(OvenquillEnvelopes plugin){this.plugin=plugin;}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){String sub=args.length==0?"help":args[0].toLowerCase(Locale.ROOT);switch(sub){
        case "help"->{sender.sendMessage("/envelope admin|create|delete|list|give|giveall|claim|reload|status");}
        case "admin"->{if(!(sender instanceof Player p)||!check(sender,"ovenquill.envelopes.admin"))return true;var inv=Bukkit.createInventory(null,54,Component.text("✦ OVENQUILL | Конверты"));int slot=0;for(var t:plugin.service().types().values()){ItemStack icon=new ItemStack(Material.PAPER);icon.editMeta(m->m.displayName(Component.text(t.id()+" — "+t.name())));inv.setItem(slot++,icon);if(slot>=45)break;}p.openInventory(inv);}
        case "create"->{if(!(sender instanceof Player p)||args.length<2||!check(sender,"ovenquill.envelopes.create")){sender.sendMessage("Использование: /envelope create <id> [all|random]");return true;}String id=args[1].toLowerCase(Locale.ROOT);if(!id.matches("[a-z0-9_-]{1,48}")){sender.sendMessage("ID: только a-z, 0-9, _ и -");return true;}ItemStack reward=p.getInventory().getItemInMainHand().clone();if(reward.getType().isAir()){sender.sendMessage("Возьми предмет-награду в основную руку.");return true;}RewardMode mode=args.length>2&&args[2].equalsIgnoreCase("random")?RewardMode.RANDOM:RewardMode.ALL;EnvelopeType type=new EnvelopeType(id,plugin.service().types().getOrDefault(id,new EnvelopeType(id,0,"",List.of(),mode,List.of(),true)).version()+1,"<aqua>✉ Подарочный конверт</aqua>",List.of("<dark_aqua>✦ OVENQUILL</dark_aqua>","","<gray>ПКМ — распечатать</gray>","<gray>Shift + ПКМ — посмотреть награды</gray>"),mode,List.of(new EnvelopeType.WeightedReward(reward,1)),true);plugin.saveAndReload(type,sender);}
        case "delete"->{if(args.length<2||!check(sender,"ovenquill.envelopes.delete"))return true;plugin.archiveAndReload(args[1],sender);}
        case "list"->{sender.sendMessage("Типы: "+String.join(", ",plugin.service().types().keySet()));}
        case "give","send"->{if(args.length<3||!check(sender,"ovenquill.envelopes.give")){sender.sendMessage("Использование: /envelope give <player> <type> [amount]");return true;}Player target=Bukkit.getPlayerExact(args[1]);if(target==null){sender.sendMessage("Игрок должен быть онлайн (офлайн-доставка доступна через очередь наград).");return true;}give(sender,target,args[2],args.length>3?parseAmount(args[3]):1);}
        case "giveall"->{if(args.length<2||!check(sender,"ovenquill.envelopes.giveall"))return true;int amount=args.length>2?parseAmount(args[2]):1;for(Player p:Bukkit.getOnlinePlayers())give(sender,p,args[1],amount);}
        case "claim"->{if(sender instanceof Player p&&check(sender,"ovenquill.envelopes.claim"))plugin.service().claim(p);}
        case "reload"->{if(check(sender,"ovenquill.envelopes.reload"))plugin.reloadAll(sender);}
        case "status"->{if(check(sender,"ovenquill.envelopes.status"))plugin.status(sender);}
        default->sender.sendMessage("Неизвестная подкоманда. /envelope help");}return true;}
    private void give(CommandSender sender,Player target,String id,int amount){var type=plugin.service().types().get(id);if(type==null){sender.sendMessage("Тип не найден: "+id);return;}amount=Math.max(1,Math.min(64,amount));for(int i=0;i<amount;i++){UUID instance=UUID.randomUUID();plugin.storage().createInstance(instance,type,null).thenRun(()->Bukkit.getScheduler().runTask(plugin,()->{var left=target.getInventory().addItem(plugin.service().createItem(type,instance));left.values().forEach(item->plugin.storage().queue(target.getUniqueId(),item));}));}sender.sendMessage("Выдано: "+amount+" × "+id+" → "+target.getName());}
    private int parseAmount(String s){try{return Integer.parseInt(s);}catch(NumberFormatException e){return 1;}}
    private boolean check(CommandSender s,String permission){if(s.hasPermission(permission))return true;s.sendMessage("Недостаточно прав: "+permission);return false;}
    @Override public List<String> onTabComplete(CommandSender s,Command c,String a,String[] args){if(args.length==1)return filter(List.of("admin","create","delete","list","give","giveall","claim","reload","status"),args[0]);if(args.length==2&&(args[0].equalsIgnoreCase("delete")||args[0].equalsIgnoreCase("giveall")))return filter(plugin.service().types().keySet(),args[1]);if(args.length==3&&args[0].equalsIgnoreCase("give"))return filter(plugin.service().types().keySet(),args[2]);return List.of();}
    private List<String> filter(Collection<String> values,String prefix){return values.stream().filter(x->x.startsWith(prefix.toLowerCase(Locale.ROOT))).sorted().toList();}
}

package ru.ovenquill.envelopes.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import ru.ovenquill.envelopes.service.EnvelopeService;

public final class EnvelopeListener implements Listener {
    private final EnvelopeService service;
    public EnvelopeListener(EnvelopeService service){this.service=service;}
    @EventHandler(ignoreCancelled=true) public void interact(PlayerInteractEvent e){if(e.getAction()!=Action.RIGHT_CLICK_AIR&&e.getAction()!=Action.RIGHT_CLICK_BLOCK)return;if(service.inspect(e.getItem()).isEmpty())return;e.setCancelled(true);if(e.getPlayer().isSneaking()){if(e.getPlayer().hasPermission("ovenquill.envelopes.preview"))service.preview(e.getPlayer(),e.getItem());}else if(e.getPlayer().hasPermission("ovenquill.envelopes.use"))service.open(e.getPlayer(),e.getItem());}
    @EventHandler public void previewClick(InventoryClickEvent e){if(e.getView().title().equals(net.kyori.adventure.text.Component.text("✦ Содержимое конверта")))e.setCancelled(true);}
    @EventHandler public void previewDrag(InventoryDragEvent e){if(e.getView().title().equals(net.kyori.adventure.text.Component.text("✦ Содержимое конверта")))e.setCancelled(true);}
}

package ru.ovenquill.envelopes.model;

import org.bukkit.inventory.ItemStack;
import java.util.List;

public record EnvelopeType(String id, int version, String name, List<String> lore,
                           RewardMode mode, List<WeightedReward> rewards, boolean active) {
    public record WeightedReward(ItemStack item, double weight) {}
}

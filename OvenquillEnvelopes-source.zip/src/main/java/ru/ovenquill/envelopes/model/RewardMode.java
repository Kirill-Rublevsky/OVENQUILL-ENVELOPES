package ru.ovenquill.envelopes.model;
public enum RewardMode { ALL, RANDOM }

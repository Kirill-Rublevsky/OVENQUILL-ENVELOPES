package ru.ovenquill.envelopes.security;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;

public final class EnvelopeSigner {
    private final SecretKeySpec key;
    public EnvelopeSigner(byte[] secret) { this.key = new SecretKeySpec(secret, "HmacSHA256"); }
    public String sign(String id, String type, int version) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(key);
            return HexFormat.of().formatHex(mac.doFinal((id + "\0" + type + "\0" + version).getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) { throw new IllegalStateException("HMAC unavailable", e); }
    }
    public boolean verify(String signature, String id, String type, int version) {
        return signature != null && MessageDigest.isEqual(signature.getBytes(StandardCharsets.US_ASCII), sign(id, type, version).getBytes(StandardCharsets.US_ASCII));
    }
}

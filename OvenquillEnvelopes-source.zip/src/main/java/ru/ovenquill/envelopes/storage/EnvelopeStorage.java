package ru.ovenquill.envelopes.storage;

import org.bukkit.inventory.ItemStack;
import ru.ovenquill.envelopes.model.EnvelopeType;
import ru.ovenquill.envelopes.model.RewardMode;
import ru.ovenquill.envelopes.util.ItemCodec;

import java.nio.file.Path;
import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Function;

/** One connection on one worker: no pool, no main-thread I/O, deterministic transaction ordering. */
public final class EnvelopeStorage implements AutoCloseable {
    public enum ReserveResult { RESERVED, USED, MISSING, BUSY }
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "ovenquill-envelopes-db"); t.setDaemon(true); return t;
    });
    private final Connection connection;

    public EnvelopeStorage(Path file) throws SQLException {
        connection = DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath());
        try (Statement s = connection.createStatement()) {
            s.execute("PRAGMA journal_mode=WAL"); s.execute("PRAGMA synchronous=NORMAL");
            s.execute("PRAGMA foreign_keys=ON"); s.execute("PRAGMA busy_timeout=3000");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS envelope_types(id TEXT PRIMARY KEY, version INTEGER NOT NULL, name TEXT NOT NULL, lore TEXT NOT NULL, mode TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS envelope_rewards(type_id TEXT NOT NULL, version INTEGER NOT NULL, slot INTEGER NOT NULL, item TEXT NOT NULL, weight REAL NOT NULL, PRIMARY KEY(type_id,version,slot))");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS envelope_instances(id TEXT PRIMARY KEY, type_id TEXT NOT NULL, version INTEGER NOT NULL, recipient TEXT, status TEXT NOT NULL, created_at INTEGER NOT NULL, opened_at INTEGER)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS envelope_openings(operation_id TEXT PRIMARY KEY, instance_id TEXT UNIQUE NOT NULL, player_id TEXT NOT NULL, selected_reward TEXT, state TEXT NOT NULL, created_at INTEGER NOT NULL)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS envelope_deliveries(id TEXT PRIMARY KEY, player_id TEXT NOT NULL, item TEXT NOT NULL, state TEXT NOT NULL, created_at INTEGER NOT NULL)");
            s.executeUpdate("CREATE INDEX IF NOT EXISTS idx_deliveries_player ON envelope_deliveries(player_id,state)");
        }
    }

    private <T> CompletableFuture<T> submit(SqlTask<T> task) {
        return CompletableFuture.supplyAsync(() -> { try { return task.run(); } catch (Exception e) { throw new CompletionException(e); } }, worker);
    }
    public CompletableFuture<Map<String, EnvelopeType>> loadTypes() { return submit(() -> {
        Map<String, EnvelopeType> result = new HashMap<>();
        try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM envelope_types WHERE active=1"); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String id=rs.getString("id"); int version=rs.getInt("version"); List<EnvelopeType.WeightedReward> rewards=new ArrayList<>();
                try (PreparedStatement rp=connection.prepareStatement("SELECT item,weight FROM envelope_rewards WHERE type_id=? AND version=? ORDER BY slot")) {
                    rp.setString(1,id); rp.setInt(2,version); try(ResultSet rr=rp.executeQuery()){ while(rr.next()) rewards.add(new EnvelopeType.WeightedReward(ItemCodec.decode(rr.getString(1)),rr.getDouble(2))); }
                }
                result.put(id,new EnvelopeType(id,version,rs.getString("name"),List.of(rs.getString("lore").split("\\n",-1)),RewardMode.valueOf(rs.getString("mode")),List.copyOf(rewards),true));
            }
        } return Map.copyOf(result);
    }); }
    public CompletableFuture<Void> saveType(EnvelopeType type) { return submit(() -> {
        connection.setAutoCommit(false);
        try (PreparedStatement p=connection.prepareStatement("INSERT INTO envelope_types(id,version,name,lore,mode,active) VALUES(?,?,?,?,?,1) ON CONFLICT(id) DO UPDATE SET version=excluded.version,name=excluded.name,lore=excluded.lore,mode=excluded.mode,active=1")) {
            p.setString(1,type.id());p.setInt(2,type.version());p.setString(3,type.name());p.setString(4,String.join("\n",type.lore()));p.setString(5,type.mode().name());p.executeUpdate();
            try(PreparedStatement d=connection.prepareStatement("DELETE FROM envelope_rewards WHERE type_id=? AND version=?")){d.setString(1,type.id());d.setInt(2,type.version());d.executeUpdate();}
            try(PreparedStatement r=connection.prepareStatement("INSERT INTO envelope_rewards(type_id,version,slot,item,weight) VALUES(?,?,?,?,?)")){int i=0;for(var reward:type.rewards()){r.setString(1,type.id());r.setInt(2,type.version());r.setInt(3,i++);r.setString(4,ItemCodec.encode(reward.item()));r.setDouble(5,reward.weight());r.addBatch();}r.executeBatch();}
            connection.commit(); return null;
        } catch(Exception e){connection.rollback();throw e;} finally{connection.setAutoCommit(true);}
    }); }
    public CompletableFuture<Void> archiveType(String id){return submit(()->{try(PreparedStatement p=connection.prepareStatement("UPDATE envelope_types SET active=0 WHERE id=?")){p.setString(1,id);p.executeUpdate();}return null;});}
    public CompletableFuture<Void> createInstance(UUID id, EnvelopeType type, UUID recipient) { return submit(() -> { try(PreparedStatement p=connection.prepareStatement("INSERT INTO envelope_instances(id,type_id,version,recipient,status,created_at) VALUES(?,?,?,?, 'ISSUED',?)")){p.setString(1,id.toString());p.setString(2,type.id());p.setInt(3,type.version());p.setString(4,recipient==null?null:recipient.toString());p.setLong(5,Instant.now().toEpochMilli());p.executeUpdate();}return null;}); }
    public CompletableFuture<ReserveResult> reserve(UUID instance, UUID player, String selectedReward) { return submit(() -> {
        connection.setAutoCommit(false);
        try {
            String status; try(PreparedStatement q=connection.prepareStatement("SELECT status FROM envelope_instances WHERE id=?")){q.setString(1,instance.toString());try(ResultSet r=q.executeQuery()){if(!r.next()){connection.rollback();return ReserveResult.MISSING;}status=r.getString(1);}}
            if(!"ISSUED".equals(status)){connection.rollback();return "OPENING".equals(status)?ReserveResult.BUSY:ReserveResult.USED;}
            try(PreparedStatement u=connection.prepareStatement("UPDATE envelope_instances SET status='OPENING' WHERE id=? AND status='ISSUED'")){u.setString(1,instance.toString());if(u.executeUpdate()!=1){connection.rollback();return ReserveResult.BUSY;}}
            try(PreparedStatement o=connection.prepareStatement("INSERT INTO envelope_openings(operation_id,instance_id,player_id,selected_reward,state,created_at) VALUES(?,?,?,?, 'RESERVED',?)")){o.setString(1,UUID.randomUUID().toString());o.setString(2,instance.toString());o.setString(3,player.toString());o.setString(4,selectedReward);o.setLong(5,Instant.now().toEpochMilli());o.executeUpdate();}
            connection.commit();return ReserveResult.RESERVED;
        }catch(Exception e){connection.rollback();throw e;}finally{connection.setAutoCommit(true);}
    }); }
    public CompletableFuture<Void> complete(UUID instance){return submit(()->{connection.setAutoCommit(false);try{try(PreparedStatement p=connection.prepareStatement("UPDATE envelope_instances SET status='OPENED',opened_at=? WHERE id=? AND status='OPENING'")){p.setLong(1,Instant.now().toEpochMilli());p.setString(2,instance.toString());p.executeUpdate();}try(PreparedStatement p=connection.prepareStatement("UPDATE envelope_openings SET state='COMPLETED' WHERE instance_id=?")){p.setString(1,instance.toString());p.executeUpdate();}connection.commit();return null;}catch(Exception e){connection.rollback();throw e;}finally{connection.setAutoCommit(true);}});}
    public CompletableFuture<Void> queue(UUID player, ItemStack item){return submit(()->{try(PreparedStatement p=connection.prepareStatement("INSERT INTO envelope_deliveries(id,player_id,item,state,created_at) VALUES(?,?,?,'PENDING',?)")){p.setString(1,UUID.randomUUID().toString());p.setString(2,player.toString());p.setString(3,ItemCodec.encode(item));p.setLong(4,Instant.now().toEpochMilli());p.executeUpdate();}return null;});}
    public CompletableFuture<List<Map.Entry<String,ItemStack>>> pending(UUID player){return submit(()->{List<Map.Entry<String,ItemStack>> list=new ArrayList<>();try(PreparedStatement p=connection.prepareStatement("SELECT id,item FROM envelope_deliveries WHERE player_id=? AND state='PENDING' ORDER BY created_at LIMIT 54")){p.setString(1,player.toString());try(ResultSet r=p.executeQuery()){while(r.next())list.add(Map.entry(r.getString(1),ItemCodec.decode(r.getString(2))));}}return list;});}
    public CompletableFuture<Void> delivered(Collection<String> ids){return submit(()->{try(PreparedStatement p=connection.prepareStatement("UPDATE envelope_deliveries SET state='DELIVERED' WHERE id=?")){for(String id:ids){p.setString(1,id);p.addBatch();}p.executeBatch();}return null;});}
    public CompletableFuture<Integer> pendingCount(){return submit(()->{try(Statement s=connection.createStatement();ResultSet r=s.executeQuery("SELECT count(*) FROM envelope_deliveries WHERE state='PENDING'")){return r.next()?r.getInt(1):0;}});}
    @Override public void close(){worker.shutdown();try{worker.awaitTermination(3,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}try{connection.close();}catch(SQLException ignored){}}
    @FunctionalInterface private interface SqlTask<T>{T run() throws Exception;}
}

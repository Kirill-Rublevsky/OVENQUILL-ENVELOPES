package ru.ovenquill.envelopes.util;

import org.bukkit.inventory.ItemStack;
import java.io.*;
import java.util.Base64;

public final class ItemCodec {
    private ItemCodec() {}
    public static String encode(ItemStack item) {
        try (var bytes = new ByteArrayOutputStream(); var out = new DataOutputStream(bytes)) {
            byte[] raw = item.serializeAsBytes();
            out.writeInt(raw.length); out.write(raw);
            return Base64.getEncoder().encodeToString(bytes.toByteArray());
        } catch (IOException e) { throw new UncheckedIOException(e); }
    }
    public static ItemStack decode(String data) {
        try (var in = new DataInputStream(new ByteArrayInputStream(Base64.getDecoder().decode(data)))) {
            return ItemStack.deserializeBytes(in.readNBytes(in.readInt()));
        } catch (IOException e) { throw new UncheckedIOException(e); }
    }
}

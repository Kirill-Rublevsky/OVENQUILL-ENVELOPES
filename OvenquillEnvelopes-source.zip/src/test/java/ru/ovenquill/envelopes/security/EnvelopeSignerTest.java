package ru.ovenquill.envelopes.security;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class EnvelopeSignerTest { @Test void rejectsTampering(){var s=new EnvelopeSigner(new byte[32]);var sig=s.sign("uuid","common",1);assertTrue(s.verify(sig,"uuid","common",1));assertFalse(s.verify(sig,"uuid","legendary",1));assertFalse(s.verify(sig,"uuid","common",2));} }
